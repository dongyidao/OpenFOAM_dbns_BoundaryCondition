/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | foam-extend: Open Source CFD
   \\    /   O peration     |
    \\  /    A nd           | For copyright notice see file Copyright
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of foam-extend.

    foam-extend is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or (at your
    option) any later version.

    foam-extend is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with foam-extend.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "leastSquaresGhostVectors.H"
#include "surfaceFields.H"
#include "volFields.H"
#include "mapPolyMesh.H"

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{
    defineTypeNameAndDebug(leastSquaresGhostVectors, 0);
}


// * * * * * * * * * * * * * * * * Constructors * * * * * * * * * * * * * * //

Foam::leastSquaresGhostVectors::leastSquaresGhostVectors(const fvMesh& mesh)
:
    MeshObject<fvMesh, leastSquaresGhostVectors>(mesh),
    pVectorsPtr_(NULL),
    nVectorsPtr_(NULL)
{}


// * * * * * * * * * * * * * * * * Destructor * * * * * * * * * * * * * * * //

Foam::leastSquaresGhostVectors::~leastSquaresGhostVectors()
{
    deleteDemandDrivenData(pVectorsPtr_);
    deleteDemandDrivenData(nVectorsPtr_);
}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::leastSquaresGhostVectors::makeLeastSquaresGhostVectors() const
{
    if (debug)
    {
        Info<< "leastSquaresVectors::makeLeastSquaresGhostVectors() :"
            << "Constructing least square ghost gradient vectors"
            << endl;
    }

    Info<<"Constructing least square ghost gradient vectors"<< nl << endl;

    pVectorsPtr_ = new surfaceVectorField
    (
        IOobject
        (
            "LeastSquaresGhostP",
            mesh().pointsInstance(),
            mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        mesh(),
        dimensionedVector("zero", dimless/dimLength, vector::zero)
    );
    surfaceVectorField& lsP = *pVectorsPtr_;

    nVectorsPtr_ = new surfaceVectorField
    (
        IOobject
        (
            "LeastSquaresGhostN",
            mesh().pointsInstance(),
            mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        mesh(),
        dimensionedVector("zero", dimless/dimLength, vector::zero)
    );
    surfaceVectorField& lsN = *nVectorsPtr_;

    // Set local references to mesh data
    const unallocLabelList& owner = mesh().owner();
    const unallocLabelList& neighbour = mesh().neighbour();
    const volVectorField& C = mesh().C();

    // Set up temporary storage for the dd tensor (before inversion)
    symmTensorField dd(mesh().nCells(), symmTensor::zero);

    forAll(owner, faceI)
    {
        label own = owner[faceI];
        label nei = neighbour[faceI];

        vector d = C[nei] - C[own];
        symmTensor wdd = (1.0/magSqr(d))*sqr(d);

        dd[own] += wdd;
        dd[nei] += wdd;
    }

    forAll(lsP.boundaryField(), patchI)
    {
        const fvPatch& p = mesh().boundary()[patchI];
        const unallocLabelList& faceCells = p.patch().faceCells();

        const word bcType = mesh().boundaryMesh().types()[patchI];

        if (p.coupled())
        {
	        const vectorField pd = p.delta();

	        forAll(pd, patchFaceI)
        	{
        	    const vector& d = pd[patchFaceI];
        	    dd[faceCells[patchFaceI]] += (1.0/magSqr(d))*sqr(d);
        	}
        }
        else if (bcType == "empty")
        {
	        continue;
        }
        else
        {
	        const vectorField pd = 2.0*(p.delta() & p.nf())*p.nf();

	        forAll(pd, patchFaceI)
        	{
        	    const vector& d = pd[patchFaceI];
        	    dd[faceCells[patchFaceI]] += (1.0/magSqr(d))*sqr(d);
        	}
        }
    }

    // For easy access of neighbour coupled patch field needed for
    // lsN vectors on implicitly coupled boundaries. VV, 18/June/2014
    volSymmTensorField volInvDd
    (
        IOobject
        (
            "volInvDd",
            mesh().pointsInstance(),
            mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh(),
        dimensionedSymmTensor("zero", dimless, symmTensor::zero),
        "zeroGradient"
    );
    symmTensorField& invDd = volInvDd.internalField();
//    invDd = inv(dd);
    invDd = hinv(dd);

    // Evaluate coupled to exchange coupled neighbour field data
    // across coupled boundaries.  HJ, 18/Mar/2015
    volInvDd.boundaryField().evaluateCoupled();

    // Revisit all faces and calculate the lsP and lsN vectors
    forAll(owner, faceI)
    {
        label own = owner[faceI];
        label nei = neighbour[faceI];

        vector d = C[nei] - C[own];
        scalar magSfByMagSqrd = 1.0/magSqr(d);

        lsP[faceI] = magSfByMagSqrd*(invDd[own] & d);
        lsN[faceI] = -magSfByMagSqrd*(invDd[nei] & d);
    }

    forAll(lsP.boundaryField(), patchI)
    {
        fvsPatchVectorField& patchLsP = lsP.boundaryField()[patchI];
        fvsPatchVectorField& patchLsN = lsN.boundaryField()[patchI];
        const fvPatch& p = mesh().boundary()[patchI];
        const unallocLabelList& faceCells = p.faceCells();

        const word bcType = mesh().boundaryMesh().types()[patchI];

        if (p.coupled())
        {
	        const vectorField pd = p.delta();
	        
            const symmTensorField invDdNei =
                volInvDd.boundaryField()[patchI].patchNeighbourField();

            forAll(pd, patchFaceI)
            {
                const vector& d = pd[patchFaceI];

                patchLsP[patchFaceI] = (1.0/magSqr(d))
                   *(invDd[faceCells[patchFaceI]] & d);

                patchLsN[patchFaceI] = - (1.0/magSqr(d))
                   *(invDdNei[patchFaceI] & d);
            }
        }
        else if (bcType == "empty")
        {
	        continue;
        }
        else
        {
	        const vectorField pd = 2.0*(p.delta() & p.nf())*p.nf();
	        
            forAll(pd, patchFaceI)
            {
                const vector& d = pd[patchFaceI];

                patchLsP[patchFaceI] = (1.0/magSqr(d))
                   *(invDd[faceCells[patchFaceI]] & d);
            }
        }
    }

    if (debug)
    {
        Info<< "leastSquaresGhostVectors::makeLeastSquaresGhostVectors() :"
            << "Finished constructing least square ghost gradient vectors"
            << endl;
    }
}


const Foam::surfaceVectorField& Foam::leastSquaresGhostVectors::pVectors() const
{
    if (!pVectorsPtr_)
    {
        makeLeastSquaresGhostVectors();
    }

    return *pVectorsPtr_;
}


const Foam::surfaceVectorField& Foam::leastSquaresGhostVectors::nVectors() const
{
    if (!nVectorsPtr_)
    {
        makeLeastSquaresGhostVectors();
    }

    return *nVectorsPtr_;
}


bool Foam::leastSquaresGhostVectors::movePoints() const
{
    if (debug)
    {
        InfoIn("bool leastSquaresGhostVectors::movePoints() const")
            << "Clearing least square data" << endl;
    }

    deleteDemandDrivenData(pVectorsPtr_);
    deleteDemandDrivenData(nVectorsPtr_);

    return true;
}


bool Foam::leastSquaresGhostVectors::updateMesh(const mapPolyMesh& mpm) const
{
    if (debug)
    {
        InfoIn
        (
            "bool leastSquaresVectors::updateMesh(const mapPolyMesh&) const"
        )   << "Clearing least square data" << endl;
    }

    deleteDemandDrivenData(pVectorsPtr_);
    deleteDemandDrivenData(nVectorsPtr_);

    return true;
}

// ************************************************************************* //
