/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright held by original author
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Application
    AUSMPWplusFlux

Author
    Yidao Dong  All rights reserved.

\*---------------------------------------------------------------------------*/

#include "AUSMPWplusFlux.H"

// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::AUSMPWplusFlux::evaluateFlux
(
    scalar& rhoFlux,
    vector& rhoUFlux,
    scalar& rhoEFlux,
    const scalar& pLeft,
    const scalar& pRight,
    const vector& ULeft,
    const vector& URight,
    const scalar& TLeft,
    const scalar& TRight,
    const scalar& RLeft,
    const scalar& RRight,
    const scalar& CvLeft,
    const scalar& CvRight,
    const vector& Sf,
    const scalar& magSf
) const
{
        // bounding variables
        const scalar rhoMin = SMALL;

        // normal vector
        const vector normalVector = Sf/magSf;

	// Step 1: decode left and right:

        // Compute conservative variables assuming perfect gas law

        // decode rho left and right:
        scalar rhoLeft = pLeft/(RLeft*TLeft);
        scalar rhoRight = pRight/(RRight*TRight);
        
        // Adiabatic exponent is constant for ideal gas but if Cp=Cp(T)
        // it must be computed for each cell and evaluated at each face
        // through reconstruction
        const scalar kappaLeft = (CvLeft + RLeft)/CvLeft;
        const scalar kappaRight = (CvRight + RRight)/CvRight;
        const scalar kappa = 0.5*(kappaLeft + kappaRight);

        // speed of sound, for left and right side, assuming perfect gas
        const scalar aLeft  = Foam::sqrt(max(SMALL,kappaLeft *pLeft /max(rhoLeft, rhoMin)));
        const scalar aRight = Foam::sqrt(max(SMALL,kappaRight*pRight/max(rhoRight,rhoMin)));

        // TotalEnergy
        const scalar HLeft =
            pLeft/rhoLeft*kappaLeft/(kappaLeft - 1.0) + (0.5*magSqr(ULeft));
        const scalar HRight =
            pRight/rhoRight*kappaRight/(kappaRight - 1.0) + (0.5*magSqr(URight));

        // compute qLeft and qRight (q_{l,r} = U_{l,r} \bullet n)
        const scalar qLeft  = (ULeft & normalVector);
        const scalar qRight = (URight & normalVector);

	// compute normal enthalpy
	const scalar HLeftNormal =
            pLeft/rhoLeft*kappaLeft/(kappaLeft - 1.0) + (0.5*magSqr(qLeft));
        const scalar HRightNormal =
            pRight/rhoRight*kappaRight/(kappaRight - 1.0) + (0.5*magSqr(qRight));
        
        // aTilde simple average
	//const scalar aTilde = 0.5*(aLeft+aRight);
	const scalar twoGamaMin1ByGamaPlus1 = 2.0*(kappa - 1.0)/(kappa + 1.0);
	//const scalar csSqr = twoGamaMin1ByGamaPlus1*0.5*(HLeftNormal + HRightNormal);    //2001
	const scalar csSqr = twoGamaMin1ByGamaPlus1*min(HLeftNormal, HRightNormal);   //2005
	const scalar cs = sqrt(csSqr);
	const scalar aTilde = ((qLeft + qRight) >= 0 ? csSqr/max(fabs(qLeft),cs) : csSqr/max(fabs(qRight),cs));

	const scalar aTildeRec = 1.0/aTilde;
	const scalar MaLeft = qLeft*aTildeRec;
	const scalar MaRight = qRight*aTildeRec;

	scalar pLeftPos, MaLeftPos;
	scalar pRightNeg, MaRightNeg;

	if (fabs(MaLeft) >= 1.0)
	{
	    pLeftPos = 0.5 + 0.5*sign(MaLeft);
	    MaLeftPos = 0.5*(MaLeft + fabs(MaLeft));
	}
	else
	{
	    pLeftPos = 0.25*sqr(MaLeft + 1.0)*(2.0 - MaLeft);
	    MaLeftPos = 0.25*sqr(MaLeft + 1.0);
	}

	if (fabs(MaRight) >= 1.0)
	{
	    pRightNeg = 0.5 - 0.5*sign(MaRight);
	    MaRightNeg = 0.5*(MaRight - fabs(MaRight));
	}
	else
	{
	    pRightNeg = 0.25*sqr(MaRight - 1.0)*(2.0 + MaRight);
	    MaRightNeg = -0.25*sqr(MaRight - 1.0);
	}

	const scalar pTilde = pLeftPos*pLeft + pRightNeg*pRight;

	const scalar omega = 1.0 - pow(min(pLeft/pRight,pRight/pLeft),3.0);
	
        scalar fLeft, fRight;
        fLeft = sign(fabs(MaLeft) - 1.0);
	fLeft = 0.5*(fabs(fLeft) - fLeft)*(pLeft/pTilde - 1.0);
	fRight = sign(fabs(MaRight) - 1.0);
	fRight = 0.5*(fabs(fRight) - fRight)*(pRight/pTilde - 1.0);

        //Info<<fabs(-5.2)<<nl<<endl;
        //Info<<"1" <<MaLeft<< nl << endl;
        //Info<<"2" <<MaRight<< nl << endl;
        //Info<<"3" <<pLeftPos<< nl << endl;
        //Info<<"4" <<pRightNeg<< nl << endl;
        //Info<<"5" <<MaLeftPos<< nl << endl;
        //Info<<"6" <<MaRightNeg<< nl << endl;
        //Info<<"7" <<fLeft<< nl << endl;
        //Info<<"8" <<fRight<< nl << endl;

        /*if (pTilde == 0.0)
        {
            fLeft = 0.0;
            fRight = 0.0;
        }
        else
        {
            fLeft = pLeft/pTilde - 1.0;
            fRight = pRight/pTilde - 1.0;
        }*/

	scalar MaLeftTilde, MaRightTilde;
	if ((MaLeftPos + MaRightNeg) >= 0.0)
	{
	    MaLeftTilde = MaLeftPos + MaRightNeg*((1.0 - omega)*(1.0 + fRight) - fLeft);
	    MaRightTilde = MaRightNeg*omega*(1.0 + fRight);
	}
	else
	{
	    MaLeftTilde = MaLeftPos*omega*(1.0 + fLeft);
	    MaRightTilde = MaRightNeg + MaLeftPos*((1.0 - omega)*(1.0 + fLeft) - fRight);
	}

	MaLeftTilde = MaLeftTilde*rhoLeft*aTilde;
	MaRightTilde = MaRightTilde*rhoRight*aTilde;

        // refer to the origial Paper from Liou, J. Comp. Physics 208 (2005), pp. 527-569
        rhoFlux  = (MaLeftTilde + MaRightTilde)*magSf;
        rhoUFlux = (MaLeftTilde*ULeft + MaRightTilde*URight + pTilde*normalVector)*magSf;
        rhoEFlux = (MaLeftTilde*HLeft + MaRightTilde*HRight)*magSf;
}

// Definition of sign function
/*scalar sign(scalar a,scalar b)
{
    if (b > 0.0)
    {
        return a;
    }
    else if (b < 0.0)
    {
	return -a;
    }
    else
    {
	return 0 ;
    }
}*/

// ************************************************************************* //
