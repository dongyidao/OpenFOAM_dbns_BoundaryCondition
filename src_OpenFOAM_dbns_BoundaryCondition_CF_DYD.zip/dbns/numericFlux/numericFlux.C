/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | foam-extend: Open Source CFD
   \\    /   O peration     |
    \\  /    A nd           | For copyright notice see file Copyright
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of foam-extend.

    foam-extend is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or (at your
    option) any later version.

    foam-extend is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with foam-extend.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "numericFlux.H"

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
template<class Flux, class Limiter>
Foam::numericFlux<Flux, Limiter>::numericFlux
(
    const volScalarField& p,
    const volVectorField& U,
    const volScalarField& T,
    basicThermo& thermo
)
:
    numericFluxBase<Flux>(),
    mesh_(p.mesh()),
    p_(p),
    U_(U),
    T_(T),
    thermo_(thermo),
    rhoFlux_
    (
        IOobject
        (
            "phi",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        (linearInterpolate(thermo_.rho()*U_) & mesh_.Sf())
    ),
    rhoUFlux_
    (
        IOobject
        (
            "rhoUFlux",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        rhoFlux_*linearInterpolate(U_)
    ),
    rhoEFlux_
    (
        IOobject
        (
            "rhoEFlux",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        rhoFlux_*linearInterpolate(thermo.Cv()*T_ + 0.5*magSqr(U_))
    ),
    gradP_(fvc::grad(p_)),
    gradU_(fvc::grad(U_)),
    gradT_(fvc::grad(T_))
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class Flux, class Limiter>
void Foam::numericFlux<Flux, Limiter>::computeFlux()
{
    // Get face-to-cell addressing: face area point from owner to neighbour
    const unallocLabelList& owner = mesh_.owner();
    const unallocLabelList& neighbour = mesh_.neighbour();

    // Get the face area vector
    const surfaceVectorField& Sf = mesh_.Sf();
    const surfaceScalarField& magSf = mesh_.magSf();

    const volVectorField& cellCentre = mesh_.C();
    const surfaceVectorField& faceCentre = mesh_.Cf();

    // Thermodynamics
    const volScalarField Cv = thermo_.Cv();
    const volScalarField R  = thermo_.Cp() - Cv;

    gradP_ = fvc::grad(p_);
    gradP_.correctBoundaryConditions();

    gradU_ = fvc::grad(U_);
    gradU_.correctBoundaryConditions();

    gradT_ = fvc::grad(T_);
    gradT_.correctBoundaryConditions();

    MDLimiter<scalar, Limiter> scalarPLimiter
    (
        this->p_,
        this->gradP_
    );

    MDLimiter<vector, Limiter> vectorULimiter
    (
        this->U_,
        this->gradU_
    );

    MDLimiter<scalar, Limiter> scalarTLimiter
    (
        this->T_,
        this->gradT_
    );

    // Get limiters
    const volScalarField& pLimiter = scalarPLimiter.phiLimiter();
    const volVectorField& ULimiter = vectorULimiter.phiLimiter();
    const volScalarField& TLimiter = scalarTLimiter.phiLimiter();

    // Calculate fluxes at internal faces
    forAll (owner, faceI)
    {
        const label own = owner[faceI];
        const label nei = neighbour[faceI];

        const vector deltaRLeft = faceCentre[faceI] - cellCentre[own];
        const vector deltaRRight = faceCentre[faceI] - cellCentre[nei];

        // calculate fluxes with reconstructed primitive variables at faces
        Flux::evaluateFlux
        (
            rhoFlux_[faceI],
            rhoUFlux_[faceI],
            rhoEFlux_[faceI],
            p_[own] + pLimiter[own]*(deltaRLeft & gradP_[own]),
            p_[nei] + pLimiter[nei]*(deltaRRight & gradP_[nei]),
            U_[own] + cmptMultiply(ULimiter[own], (deltaRLeft & gradU_[own])),
            U_[nei] + cmptMultiply(ULimiter[nei], (deltaRRight & gradU_[nei])),
            T_[own] + TLimiter[own]*(deltaRLeft & gradT_[own]),
            T_[nei] + TLimiter[nei]*(deltaRRight & gradT_[nei]),
            R[own],
            R[nei],
            Cv[own],
            Cv[nei],
            Sf[faceI],
            magSf[faceI]
        );
    }

    // Get boundary condition treatment type dyd 20160408
    label typeTreatment = 0;
    
    if (mesh_.solutionDict().found("bcTreatment"))
    {
        dictionary bcTreatment = mesh_.solutionDict().subDict("bcTreatment");
        if (bcTreatment.found("original")) typeTreatment = 0;
        if (bcTreatment.found("modified")) typeTreatment = 1;
    }

    // Update boundary field and values
    forAll (rhoFlux_.boundaryField(), patchi)
    {
        const fvPatch& curPatch = p_.boundaryField()[patchi].patch();

        // Fluxes
        fvsPatchScalarField& pRhoFlux  = rhoFlux_.boundaryField()[patchi];
        fvsPatchVectorField& pRhoUFlux = rhoUFlux_.boundaryField()[patchi];
        fvsPatchScalarField& pRhoEFlux = rhoEFlux_.boundaryField()[patchi];

        // Patch fields
        const fvPatchScalarField& pp = p_.boundaryField()[patchi];
        const vectorField& pU = U_.boundaryField()[patchi];
        const scalarField& pT = T_.boundaryField()[patchi];

        // Thermal variables
        const scalarField& pCv = Cv.boundaryField()[patchi];
        const scalarField& pR = R.boundaryField()[patchi];

        // Gradients
        const fvPatchVectorField& pGradP = gradP_.boundaryField()[patchi];
        const fvPatchTensorField& pGradU = gradU_.boundaryField()[patchi];
        const fvPatchVectorField& pGradT = gradT_.boundaryField()[patchi];

        // Limiters
        const fvPatchScalarField& pPatchLim = pLimiter.boundaryField()[patchi];
        const fvPatchVectorField& UPatchLim = ULimiter.boundaryField()[patchi];
        const fvPatchScalarField& TPatchLim = TLimiter.boundaryField()[patchi];

        // Face areas
        const fvsPatchVectorField& pSf = Sf.boundaryField()[patchi];
        const fvsPatchScalarField& pMagSf = magSf.boundaryField()[patchi];


        if (pp.coupled())
        {
            // Coupled patch
            const scalarField ppLeft  =
                p_.boundaryField()[patchi].patchInternalField();

            const scalarField ppRight =
                p_.boundaryField()[patchi].patchNeighbourField();

            const vectorField pULeft  =
                U_.boundaryField()[patchi].patchInternalField();

            const vectorField pURight =
                U_.boundaryField()[patchi].patchNeighbourField();

            const scalarField pTLeft  =
                T_.boundaryField()[patchi].patchInternalField();

            const scalarField pTRight =
                T_.boundaryField()[patchi].patchNeighbourField();

            // Gradients
            const vectorField pgradPLeft = pGradP.patchInternalField();
            const vectorField pgradPRight = pGradP.patchNeighbourField();

            const tensorField pgradULeft = pGradU.patchInternalField();
            const tensorField pgradURight = pGradU.patchNeighbourField();

            const vectorField pgradTLeft = pGradT.patchInternalField();
            const vectorField pgradTRight = pGradT.patchNeighbourField();

            // Geometry: call the raw cell-to-face vector by calling
            // the base patch (cell-to-face) delta coefficient
            // Work out the right delta from the cell-to-cell delta
            // across the coupled patch and left delta
            vectorField pDeltaRLeft = curPatch.fvPatch::delta();
            vectorField pDdeltaRRight = pDeltaRLeft - curPatch.delta();

            // Limiters

            const scalarField ppLimiterLeft = pPatchLim.patchInternalField();
            const scalarField ppLimiterRight = pPatchLim.patchNeighbourField();

            const vectorField pULimiterLeft = UPatchLim.patchInternalField();
            const vectorField pULimiterRight = UPatchLim.patchNeighbourField();

            const scalarField pTLimiterLeft = TPatchLim.patchInternalField();
            const scalarField pTLimiterRight = TPatchLim.patchNeighbourField();

            forAll (pp, facei)
            {
                Flux::evaluateFlux
                (
                    pRhoFlux[facei],
                    pRhoUFlux[facei],
                    pRhoEFlux[facei],

                    ppLeft[facei]
                  + ppLimiterLeft[facei]*
                    (pDeltaRLeft[facei] & pgradPLeft[facei]),

                    ppRight[facei]
                  + ppLimiterRight[facei]*
                    (pDdeltaRRight[facei] & pgradPRight[facei]),

                    pULeft[facei]
                  + cmptMultiply
                    (
                        pULimiterLeft[facei],
                        pDeltaRLeft[facei] & pgradULeft[facei]
                    ),

                    pURight[facei]
                  + cmptMultiply
                    (
                        pULimiterRight[facei],
                        pDdeltaRRight[facei] & pgradURight[facei]
                    ),

                    pTLeft[facei]
                  + pTLimiterLeft[facei]*
                    (pDeltaRLeft[facei] & pgradTLeft[facei]),

                    pTRight[facei]
                  + pTLimiterRight[facei]*
                    (pDdeltaRRight[facei] & pgradTRight[facei]),

                    pR[facei],
                    pR[facei],
                    pCv[facei],
                    pCv[facei],
                    pSf[facei],
                    pMagSf[facei]
                );
            }
        }
        else
        {
            scalarField ppLeft, ppRight;
            vectorField pULeft, pURight;
            scalarField pTLeft, pTRight;

            if (typeTreatment == 0)
            {
                // Given Left and Right value from Boundary field
                ppLeft  = pp;
                pULeft  = pU;
                pTLeft  = pT;

                ppRight = pp;
                pURight = pU;
                pTRight = pT;
            }
            else if (typeTreatment == 1)
            {
                // Given Left Value of Boundary from internal field
                ppLeft  = p_.boundaryField()[patchi].patchInternalField();
                pULeft  = U_.boundaryField()[patchi].patchInternalField();
                pTLeft  = T_.boundaryField()[patchi].patchInternalField();

                // Given Gradients of patch internal field
                const vectorField pgradPLeft = pGradP.patchInternalField();
                const tensorField pgradULeft = pGradU.patchInternalField();
                const vectorField pgradTLeft = pGradT.patchInternalField();

                // Geometry: call the raw cell-to-face vector by calling
                // the base patch (cell-to-face) delta coefficient
                // Work out the right delta from the cell-to-cell delta
                // across the coupled patch and left delta
                vectorField pDeltaRLeft = curPatch.fvPatch::delta();

                // Given Limiters of patch internal field
                const scalarField ppLimiterLeft = pPatchLim.patchInternalField();
                const vectorField pULimiterLeft = UPatchLim.patchInternalField();
                const scalarField pTLimiterLeft = TPatchLim.patchInternalField();

                // Recalculate left boundary field
                forAll(pp,facei)
                {
                    ppLeft[facei] = ppLeft[facei]
                                  + ppLimiterLeft[facei]*
                                    (pDeltaRLeft[facei] & pgradPLeft[facei]);
                    
                    pULeft[facei] = pULeft[facei]
                                  + cmptMultiply
                                    (
                                        pULimiterLeft[facei],
                                        pDeltaRLeft[facei] & pgradULeft[facei]
                                    );

                    pTLeft[facei] = pTLeft[facei]
                                  + pTLimiterLeft[facei]*
                                    (pDeltaRLeft[facei] & pgradTLeft[facei]);
                }
            
                scalar pinf, uinf, vinf, winf, Tinf, Tw, Minf, pback;
                dictionary inflowPara = mesh_.solutionDict().subDict("inflowPara");
                Minf = readScalar(inflowPara.lookup("Ma"));
	            pinf = inflowPara.lookupOrDefault<scalar>("pinf",101325);
	            uinf = inflowPara.lookupOrDefault<scalar>("uinf",170);
	            vinf = inflowPara.lookupOrDefault<scalar>("vinf",0);
	            winf = inflowPara.lookupOrDefault<scalar>("winf",0);
	            Tinf = inflowPara.lookupOrDefault<scalar>("Tinf",288.15);
                Tw = inflowPara.lookupOrDefault<scalar>("Tw",288.15);
	            pback = inflowPara.lookupOrDefault<scalar>("pback",101325);

                // Right Value to be Determined || const can not be changed
                ppRight = ppLeft;
                pURight = pULeft;
                pTRight = pTLeft;

                //Catagorization of different boundary types
                //wall subsonic_inlet subsonic_outlet supersonic_inlet supersonic_outlet
                const word  bcType = mesh_.boundaryMesh().types()[patchi];
                const word& bcName = curPatch.name();

                if (bcType == "wall")
                {
                    forAll (pp, facei)
                    {
                        //Normalization of surface normal vector
                        vector normal = pSf[facei]/pMagSf[facei];
			    
                        //Calculation of contravariant velocity
                        scalar contraVel = pULeft[facei][0]*normal[0]
                                         + pULeft[facei][1]*normal[1]
                                         + pULeft[facei][2]*normal[2];
			    
                        //Implementation of normal non-penetrate condition
                        pURight[facei][0] = pULeft[facei][0] - 2.0*contraVel*normal[0];
                        pURight[facei][1] = pULeft[facei][1] - 2.0*contraVel*normal[1];
                        pURight[facei][2] = pULeft[facei][2] - 2.0*contraVel*normal[2];

                        ppRight[facei] = ppLeft[facei];
                        pTRight[facei] = pTLeft[facei];
                    }
                }
                else if (bcType == "symmetryPlane" || bcType == "empty")
                {
                    forAll (pp, facei)
                    {
                        //Normalization of surface normal vector
                        vector normal = pSf[facei]/pMagSf[facei];
			    
                        //Calculation of contravariant velocity
                        scalar contraVel = pULeft[facei][0]*normal[0]
                                         + pULeft[facei][1]*normal[1]
                                         + pULeft[facei][2]*normal[2];
			    
                        //Implementation of normal non-penetrate condition
                        pURight[facei][0] = pULeft[facei][0] - 2.0*contraVel*normal[0];
                        pURight[facei][1] = pULeft[facei][1] - 2.0*contraVel*normal[1];
                        pURight[facei][2] = pULeft[facei][2] - 2.0*contraVel*normal[2];

                        ppRight[facei] = ppLeft[facei];
                        pTRight[facei] = pTLeft[facei];
                    }
                }
                else if((bcName == "inlet") || (bcName == "outlet") || (bcName == "inflow") || (bcName == "outflow") || (bcName == "farfield"))
                {
                    forAll (pp, facei)
                    {
                        //Normalization of surface normal vector
                        vector normal = pSf[facei]/pMagSf[facei];
			    
                        //Calculation of constants and coefficients
                        scalar R_ = pR[facei];
                        scalar gamma_ = (pCv[facei] + pR[facei])/pCv[facei];
                        scalar gM1 = gamma_ - 1.0;
                        scalar halfgM1 = 0.5*gM1;
                        scalar gM1ByG = gM1/gamma_;
                        scalar GBygM1 = 1.0/gM1ByG;
                        scalar twoBygM1 = 1.0/halfgM1;
                        scalar twoGBygM1 = 2.0*GBygM1;
			    
                        //Assignment of left and right state of Riemann problem
                        scalar pl, ul, vl, wl, Tl;
                        scalar pr, ur, vr, wr, Tr;
			    
                        //The internal field is set to be the left value
                        pl = ppLeft[facei];
                        ul = pULeft[facei][0];
                        vl = pULeft[facei][1];
                        wl = pULeft[facei][2];
                        Tl = pTLeft[facei];

                        // The freestream is set to be the right value
                        pr = pinf;
                        ur = uinf;
                        vr = vinf;
                        wr = winf;
                        Tr = Tinf;

                        //Calculation of Riemann problem
                        scalar unl = ul*normal[0] + vl*normal[1] + wl*normal[2];
                        scalar unr = ur*normal[0] + vr*normal[1] + wr*normal[2];
                        scalar cl = sqrt(gamma_*R_*Tl);
                        scalar cr = sqrt(gamma_*R_*Tr);
                        scalar plr = pow(pl/pr,0.5*gM1ByG);
                        scalar um = (plr*unl/cl + unr/cr + twoBygM1*(plr - 1.0))/(plr/cl + 1.0/cr);
                        scalar ptl = 1.0 + halfgM1*(unl - um)/cl;
                        scalar ptr = 1.0 + halfgM1*(um - unr)/cr;
                        scalar pm = 0.5*(pl*pow(ptl,twoGBygM1) + 
                                         pr*pow(ptr,twoGBygM1));
                        scalar dl = pl/R_/Tl;
                        scalar dr = pr/R_/Tr;
                        scalar dml = dl*pow(pm/pl,1.0/gamma_);
                        scalar dmr = dr*pow(pm/pr,1.0/gamma_);
                        
                        ppRight[facei] = pm;
                        pURight[facei][0] = ur + (um-unr)*normal[0];
                        pURight[facei][1] = vr + (um-unr)*normal[1];
                        pURight[facei][2] = wr + (um-unr)*normal[2];
                        pTRight[facei] = pm/R_/dmr;
                    }
                }
                else if(bcName == "supInlet")
                {
                    forAll (pp, facei)
                    {
                        ppRight[facei] = pinf;
			            pURight[facei][0] = uinf;
			            pURight[facei][1] = vinf;
			            pURight[facei][2] = winf;
			            pTRight[facei] = Tinf;
                    }
                }
                else if(bcName == "supOutlet")
                {
                    forAll (pp, facei)
                    {
                        ppRight[facei] = ppLeft[facei];
			            pURight[facei] = pULeft[facei];
			            pTRight[facei] = pTLeft[facei];
                    }
                }
                else
            	{
            	    // Retain the original treatment for some bcs, such as cyclic
            	    ppLeft  = pp;
            	    pULeft  = pU;
            	    pTLeft  = pT;

            	    ppRight = pp;
            	    pURight = pU;
            	    pTRight = pT;
            	}
            }

            // Given the Left and Right value, calculate boundary flux via Riemann solver
            forAll (pp, facei)
            {
                // Calculate fluxes
                Flux::evaluateFlux
                (
                    pRhoFlux[facei],
                    pRhoUFlux[facei],
                    pRhoEFlux[facei],
                    ppLeft[facei],
                    ppRight[facei],
                    pULeft[facei],
                    pURight[facei],
                    pTLeft[facei],
                    pTRight[facei],
                    pR[facei],
                    pR[facei],
                    pCv[facei],
                    pCv[facei],
                    pSf[facei],
                    pMagSf[facei]
                );
            }
        }
    }
}


// ************************************************************************* //
