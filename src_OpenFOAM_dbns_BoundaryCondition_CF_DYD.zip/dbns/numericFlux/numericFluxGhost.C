/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | foam-extend: Open Source CFD
   \\    /   O peration     |
    \\  /    A nd           | For copyright notice see file Copyright
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of foam-extend.

    foam-extend is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or (at your
    option) any later version.

    foam-extend is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with foam-extend.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "numericFluxGhost.H"

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

// Construct from components
template<class Flux, class Limiter>
Foam::numericFluxGhost<Flux, Limiter>::numericFluxGhost
(
    const volScalarField& p,
    const volVectorField& U,
    const volScalarField& T,
    basicThermo& thermo
)
:
    numericFluxBase<Flux>(),
    mesh_(p.mesh()),
    p_(p),
    U_(U),
    T_(T),
    thermo_(thermo),
    rhoFlux_
    (
        IOobject
        (
            "phi",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        (linearInterpolate(thermo_.rho()*U_) & mesh_.Sf())
    ),
    rhoUFlux_
    (
        IOobject
        (
            "rhoUFlux",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        rhoFlux_*linearInterpolate(U_)
    ),
    rhoEFlux_
    (
        IOobject
        (
            "rhoEFlux",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        rhoFlux_*linearInterpolate(thermo.Cv()*T_ + 0.5*magSqr(U_))
    ),
    gradP_(fvc::grad(p_)),
    gradU_(fvc::grad(U_)),
    gradT_(fvc::grad(T_))
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

template<class Flux, class Limiter>
void Foam::numericFluxGhost<Flux, Limiter>::computeFlux()
{
    // Get face-to-cell addressing: face area point from owner to neighbour
    const unallocLabelList& owner = mesh_.owner();
    const unallocLabelList& neighbour = mesh_.neighbour();

    // Get the face area vector
    const surfaceVectorField& Sf = mesh_.Sf();
    const surfaceScalarField& magSf = mesh_.magSf();

    const volVectorField& cellCentre = mesh_.C();
    const surfaceVectorField& faceCentre = mesh_.Cf();

    // Thermodynamics
    const volScalarField Cv = thermo_.Cv();
    const volScalarField R  = thermo_.Cp() - Cv;

    // Set the temporary environmental variables
    volScalarField pEtmp(p_);
    volVectorField UEtmp(U_);
    volScalarField TEtmp(T_);

    // Get boundary condition treatment type dyd 20160408
    label typeTreatment = 0;

    if (mesh_.solutionDict().found("bcTreatment"))
    {
        dictionary bcTreatment = mesh_.solutionDict().subDict("bcTreatment");
        if (bcTreatment.found("original")) typeTreatment = 0;
        if (bcTreatment.found("modified")) typeTreatment = 1;
    }

    // Update boundary field and values
    forAll (rhoFlux_.boundaryField(), patchi)
    {
        const fvPatch& curPatch = p_.boundaryField()[patchi].patch();

        // Patch fields
        const fvPatchScalarField& pp = p_.boundaryField()[patchi];
        const vectorField& pU = U_.boundaryField()[patchi];
        const scalarField& pT = T_.boundaryField()[patchi];

        // Patch fields for the environmental variables
        scalarField& ppE = pEtmp.boundaryField()[patchi];
        vectorField& pUE = UEtmp.boundaryField()[patchi];
        scalarField& pTE = TEtmp.boundaryField()[patchi];

        const scalarField& pCv = Cv.boundaryField()[patchi];
        const scalarField& pR = R.boundaryField()[patchi];

        // Face areas
        const fvsPatchVectorField& pSf = Sf.boundaryField()[patchi];
        const fvsPatchScalarField& pMagSf = magSf.boundaryField()[patchi];

            scalarField ppLeft, ppRight;
            vectorField pULeft, pURight;
            scalarField pTLeft, pTRight;

            if (typeTreatment == 0)
            {
                // Given Left and Right value from Boundary field
                ppLeft  = pp;
                pULeft  = pU;
                pTLeft  = pT;

                ppRight = pp;
                pURight = pU;
                pTRight = pT;
            }
            else if (typeTreatment == 1)
            {
                // Given Left Value of Boundary from internal field
                ppLeft  = p_.boundaryField()[patchi].patchInternalField();
                pULeft  = U_.boundaryField()[patchi].patchInternalField();
                pTLeft  = T_.boundaryField()[patchi].patchInternalField();

                // Geometry: call the raw cell-to-face vector by calling
                // the base patch (cell-to-face) delta coefficient
                // Work out the right delta from the cell-to-cell delta
                // across the coupled patch and left delta
                vectorField pDeltaRLeft = curPatch.fvPatch::delta();
            
                scalar pinf, uinf, vinf, winf, Tinf, Tw, Minf, pback;
                dictionary inflowPara = mesh_.solutionDict().subDict("inflowPara");
                Minf = readScalar(inflowPara.lookup("Ma"));
	            pinf = inflowPara.lookupOrDefault<scalar>("pinf",101325);
	            uinf = inflowPara.lookupOrDefault<scalar>("uinf",170);
	            vinf = inflowPara.lookupOrDefault<scalar>("vinf",0);
	            winf = inflowPara.lookupOrDefault<scalar>("winf",0);
	            Tinf = inflowPara.lookupOrDefault<scalar>("Tinf",288.15);
                Tw = inflowPara.lookupOrDefault<scalar>("Tw",288.15);
	            pback = inflowPara.lookupOrDefault<scalar>("pback",101325);

                // Right Value to be Determined || const can not be changed
                ppRight = ppLeft;
                pURight = pULeft;
                pTRight = pTLeft;

                //Catagorization of different boundary types
                //wall subsonic_inlet subsonic_outlet supersonic_inlet supersonic_outlet
                const word  bcType = mesh_.boundaryMesh().types()[patchi];
                const word& bcName = curPatch.name();

                if (bcType == "wall")
                {
                    forAll (pp, facei)
                    {
                        //Normalization of surface normal vector
                        vector normal = pSf[facei]/pMagSf[facei];
			    
                        //Calculation of contravariant velocity
                        scalar contraVel = pULeft[facei][0]*normal[0]
                                         + pULeft[facei][1]*normal[1]
                                         + pULeft[facei][2]*normal[2];
			    
                        //Implementation of normal non-penetrate condition, Euler equation
                        pURight[facei][0] = pULeft[facei][0] - 2.0*contraVel*normal[0];
                        pURight[facei][1] = pULeft[facei][1] - 2.0*contraVel*normal[1];
                        pURight[facei][2] = pULeft[facei][2] - 2.0*contraVel*normal[2];

                        ppRight[facei] = ppLeft[facei];
                        pTRight[facei] = pTLeft[facei];

                        // Assignment of surrounding variables
                        ppE[facei] = ppRight[facei];
                        pUE[facei] = pURight[facei];
                        pTE[facei] = pTRight[facei];
                    }
                }
                else if (bcType == "symmetryPlane" || bcType == "empty")
                {
                    forAll (pp, facei)
                    {
                        //Normalization of surface normal vector
                        vector normal = pSf[facei]/pMagSf[facei];
			    
                        //Calculation of contravariant velocity
                        scalar contraVel = pULeft[facei][0]*normal[0]
                                         + pULeft[facei][1]*normal[1]
                                         + pULeft[facei][2]*normal[2];
			    
                        //Implementation of normal non-penetrate condition
                        pURight[facei][0] = pULeft[facei][0] - 2.0*contraVel*normal[0];
                        pURight[facei][1] = pULeft[facei][1] - 2.0*contraVel*normal[1];
                        pURight[facei][2] = pULeft[facei][2] - 2.0*contraVel*normal[2];

                        ppRight[facei] = ppLeft[facei];
                        pTRight[facei] = pTLeft[facei];

                        // Assignment of surrounding variables
                        ppE[facei] = ppRight[facei];
                        pUE[facei] = pURight[facei];
                        pTE[facei] = pTRight[facei];
                    }
                }
                else if((bcName == "inlet") || (bcName == "outlet") || (bcName == "farfield"))
                {
                    forAll (pp, facei)
                    {
                        ppRight[facei] = pinf;
                        pURight[facei][0] = uinf;
                        pURight[facei][1] = vinf;
                        pURight[facei][2] = winf;
                        pTRight[facei] = Tinf;

                        // Assignment of surrounding variables
                        ppE[facei] = ppRight[facei];
                        pUE[facei] = pURight[facei];
                        pTE[facei] = pTRight[facei];
                    }
                }
                else if(bcName == "supInlet")
                {
                    forAll (pp, facei)
                    {
                        //ppRight[facei] = pinf;
			            //pURight[facei][0] = uinf;
			            //pURight[facei][1] = vinf;
			            //pURight[facei][2] = winf;
			            //pTRight[facei] = Tinf;

			            ppRight[facei] = pp[facei];
			            pURight[facei] = pU[facei];
			            pTRight[facei] = pT[facei];

			            // Assignment of surrounding variables
                        ppE[facei] = ppRight[facei];
                        pUE[facei] = pURight[facei];
                        pTE[facei] = pTRight[facei];
                    }
                }
                else if(bcName == "supOutlet")
                {
                    forAll (pp, facei)
                    {
                        ppRight[facei] = ppLeft[facei];
			            pURight[facei] = pULeft[facei];
			            pTRight[facei] = pTLeft[facei];

			            // Assignment of surrounding variables
                        ppE[facei] = ppRight[facei];
                        pUE[facei] = pURight[facei];
                        pTE[facei] = pTRight[facei];
                    }
                }
        }
    }

    // Set the temporary environmental variables
    const volScalarField& pE(pEtmp);
    const volVectorField& UE(UEtmp);
    const volScalarField& TE(TEtmp);
    
    gradP_ = fvc::grad(pE);
    gradP_.correctBoundaryConditions();

    gradU_ = fvc::grad(UE);
    gradU_.correctBoundaryConditions();

    gradT_ = fvc::grad(TE);
    gradT_.correctBoundaryConditions();

    MDLimiter<scalar, Limiter> scalarPPLimiter
    (
        pE,
        this->gradP_
    );

    MDLimiter<vector, Limiter> vectorUULimiter
    (
        UE,
        this->gradU_
    );

    MDLimiter<scalar, Limiter> scalarTTLimiter
    (
        TE,
        this->gradT_
    );

    // Get limiters
    const volScalarField& ppLimiter = scalarPPLimiter.phiLimiter();
    const volVectorField& UULimiter = vectorUULimiter.phiLimiter();
    const volScalarField& TTLimiter = scalarTTLimiter.phiLimiter();

    // Calculate fluxes at internal faces
    forAll (owner, faceI)
    {
        const label own = owner[faceI];
        const label nei = neighbour[faceI];

        const vector deltaRLeft = faceCentre[faceI] - cellCentre[own];
        const vector deltaRRight = faceCentre[faceI] - cellCentre[nei];

        // calculate fluxes with reconstructed primitive variables at faces
        Flux::evaluateFlux
        (
            rhoFlux_[faceI],
            rhoUFlux_[faceI],
            rhoEFlux_[faceI],
            p_[own] + ppLimiter[own]*(deltaRLeft & gradP_[own]),
            p_[nei] + ppLimiter[nei]*(deltaRRight & gradP_[nei]),
            U_[own] + cmptMultiply(UULimiter[own], (deltaRLeft & gradU_[own])),
            U_[nei] + cmptMultiply(UULimiter[nei], (deltaRRight & gradU_[nei])),
            T_[own] + TTLimiter[own]*(deltaRLeft & gradT_[own]),
            T_[nei] + TTLimiter[nei]*(deltaRRight & gradT_[nei]),
            R[own],
            R[nei],
            Cv[own],
            Cv[nei],
            Sf[faceI],
            magSf[faceI]
        );
    }

    // Calculate fluxes at boundary faces
    forAll (rhoFlux_.boundaryField(), patchi)
    {
        // Fluxes
        fvsPatchScalarField& pRhoFlux  = rhoFlux_.boundaryField()[patchi];
        fvsPatchVectorField& pRhoUFlux = rhoUFlux_.boundaryField()[patchi];
        fvsPatchScalarField& pRhoEFlux = rhoEFlux_.boundaryField()[patchi];

        const fvPatch& curPatch = p_.boundaryField()[patchi].patch();
        const unallocLabelList& boundaryCells = curPatch.faceCells();

        const scalarField& pCv = Cv.boundaryField()[patchi];
        const scalarField& pR = R.boundaryField()[patchi];

        const fvPatchScalarField& pp = p_.boundaryField()[patchi];
        const vectorField& pU = U_.boundaryField()[patchi];
        const scalarField& pT = T_.boundaryField()[patchi];
        
        scalarField ppLeft(pp);
        vectorField pULeft(pU);
        scalarField pTLeft(pT);

        // Face areas
        const fvsPatchVectorField& pSf = Sf.boundaryField()[patchi];
        const fvsPatchScalarField& pMagSf = magSf.boundaryField()[patchi];

        vectorField pDeltaRLeft = curPatch.fvPatch::delta();

        const word  bcType = mesh_.boundaryMesh().types()[patchi];
        
        forAll(pp, facei)
        {
            label cellID = boundaryCells[facei];

            ppLeft[facei] = p_[cellID] + (gradP_[cellID] & pDeltaRLeft[facei]);
            pULeft[facei] = U_[cellID] + (gradU_[cellID] & pDeltaRLeft[facei]);
            pTLeft[facei] = T_[cellID] + (gradT_[cellID] & pDeltaRLeft[facei]);

            // Calculate fluxes
            Flux::evaluateFlux
            (
                pRhoFlux[facei],
                pRhoUFlux[facei],
                pRhoEFlux[facei],
                ppLeft[facei],
                ppLeft[facei],
                pULeft[facei],
                pULeft[facei],
                pTLeft[facei],
                pTLeft[facei],
                pR[facei],
                pR[facei],
                pCv[facei],
                pCv[facei],
                pSf[facei],
                pMagSf[facei]
            );
        }
    }
}


// ************************************************************************* //
