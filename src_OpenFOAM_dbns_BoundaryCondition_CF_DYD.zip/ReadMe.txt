Source file for the paper "A comparative study of boundary conditions for the density-based solvers in the framework of OpenFOAM" published in Computers & Fluids

1-
Source file : dbns/numericFlux/numericFlux.C
Description : Calculation of numerical flux with the Riemann method
Source file : dbns/numericFlux/numericFluxGhost.C
Description : Calculation of numerical flux with the ghost cell method

2-
Source file : leastSquaresNewGrad/..
Description : Calculation of geometric quantities for the least squares gradient reconstruction with the Riemann method
Source file : leastSquaresGhostGrad/..
Description : Calculation of geometric quantities for the least squares gradient reconstruction with the ghost cell method

3-
Case : channel_quad_med
Description : Case on the medium quadrilateral grid for the 2D channel flow